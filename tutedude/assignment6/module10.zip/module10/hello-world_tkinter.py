#import tkinter

from tkinter import *

#gui interaction

window=Tk()

#adding inputs

inp= Label(window, text="Hello world")
inp.pack()


#mainloop
mainloop()